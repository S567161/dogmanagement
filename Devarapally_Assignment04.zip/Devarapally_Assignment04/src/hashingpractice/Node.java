package hashingpractice;

/**
*
* @author S567161 Udaykiranreddy Devarapally
*/
public class Node {

	int data;
    Node next;

    // Parameterized constructor to assign value to data
    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}
