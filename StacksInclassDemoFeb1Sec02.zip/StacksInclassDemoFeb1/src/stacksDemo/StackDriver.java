package stacksDemo;

public class StackDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StackAsArray myStack = new StackAsArray(6);
		myStack.push(55); myStack.push(66);myStack.push(77);
		myStack.push(88); myStack.push(99);
		System.out.println("Stack elements are: ");
		myStack.print();
		System.out.println("Stack as an array: ");
		myStack.printStack();
		int removedElement = myStack.pop();	
		System.out.println("Removed top element is: " +removedElement);
		System.out.println("Remove second top element: " +myStack.pop());
		System.out.println("Peek of stack is: " +myStack.peek());
	}

}
