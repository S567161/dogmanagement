package linkedlist;

/**
*
* @author S567161 Udaykiranreddy Devarapally
*/
public class Node {

	public String color;
	public Node next;
	
	public Node(String color) {
		this.color=color;
		this.next=next;
	}
}
