package com.example.ParametersDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParametersDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParametersDemoApplication.class, args);
	}

}
