package com.example.DogDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleWebAppDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleWebAppDemoApplication.class, args);
	}

}
