package Stackdemo;

import java.util.Iterator;
import java.util.Random;
import java.util.Stack;

public class Driver {

	public static void main(String[] args) {
		
		stackdemo randomStack = new stackdemo(10);
		Stack<Integer> oddStack = new Stack<>();

		int max=30;
		int min=10;

		Random ran = new Random();
		for(int i=0;i<10;i++) {
			int randomNumbers = ran.nextInt(max-min+1)+min;
			//System.out.print(randomNumbers);
			
			randomStack.pushRandom(randomNumbers);
		}
		System.out.println("Randomly generated numbers in randomStack is:");
		randomStack.printStack();
		
		int size = oddStack.size();
		for(int i=0;i<size;i++) {
			int top = randomStack.popRandom();
			if(top%2==1) {
				oddStack.push(top);
			}
		}
		System.out.println("Odd numbers are");
		System.out.println(oddStack);
	}

}
