package queue;
/**
*
* @author S567161 Udaykiranreddy Devarapally
*/
public class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}
